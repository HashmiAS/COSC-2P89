#!/usr/bin/php-cgi
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<head>
		<h5>OWNER-Anwar hashmi ID 6584957 ah18ai</h5>
		
		<title>MYSTORE </title>

		<link rel="stylesheet" href="styles.css">
    </head>

<body>


<?php

include 'header.html';
//include 'contactus.html';

?>

w3school
anwarhashmi.me
google images





</body>

<footer>
<?php

include 'footer.html';

?>

</footer>


</html>
